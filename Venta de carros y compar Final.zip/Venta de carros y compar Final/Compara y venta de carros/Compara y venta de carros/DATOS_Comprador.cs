﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Compara_y_venta_de_carros
{
    public partial class DATOS_Comprador : Form
    {
        public DATOS_Comprador()
        {
            InitializeComponent();
        }
        string nombre, apellido, direccion, telefono, ciudad,email;
        int i = 1;
        int pos = 0;
        private void limpiar()
        {
             txtnomb_comp.Text="";
             txtapelli_comp.Text="";
             txtemail_comp.Text="";
            txtdirec_comp.Text="";
           txtnumtelefono_comp.Text="";
            txtciud_comp.Text="";
        }
        private void btnGuardarCompr_Click(object sender, EventArgs e)
        {
            nombre =txtnomb_comp.Text ;
            apellido = txtapelli_comp.Text;
            email = txtemail_comp.Text;
             direccion=txtdirec_comp.Text ;
             telefono=txtnumtelefono_comp.Text ;
             ciudad=txtciud_comp.Text ;
                 dgvDATOS_comprador.Rows.Add(i, nombre, apellido, email, direccion, telefono, ciudad);
                 i++;
          
                 
             
             
            

            
        }

        private void btnSAlircom_Click(object sender, EventArgs e)
        {
            limpiar();
            dgvDATOS_comprador.Rows.Clear();
            this.Close();
        }

        private void btnedit_comp_Click(object sender, EventArgs e)
        {
            dgvDATOS_comprador[1, pos].Value =txtnomb_comp.Text;
            dgvDATOS_comprador[2, pos].Value =txtapelli_comp.Text;
            dgvDATOS_comprador[3, pos].Value = txtemail_comp.Text;
            dgvDATOS_comprador[4, pos].Value = txtdirec_comp.Text;
            dgvDATOS_comprador[5, pos].Value = txtnumtelefono_comp.Text;
             dgvDATOS_comprador[6, pos].Value = txtciud_comp.Text;
            
        }

        private void dgvDATOS_comprador_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pos = dgvDATOS_comprador.CurrentRow.Index;
            txtnomb_comp.Text = dgvDATOS_comprador[1, pos].Value.ToString();
            txtapelli_comp.Text = dgvDATOS_comprador[2, pos].Value.ToString();
            txtemail_comp.Text = dgvDATOS_comprador[3, pos].Value.ToString();
            txtdirec_comp.Text = dgvDATOS_comprador[4, pos].Value.ToString();
            txtnumtelefono_comp.Text = dgvDATOS_comprador[5, pos].Value.ToString();
            txtciud_comp.Text = dgvDATOS_comprador[6, pos].Value.ToString();
        }

        private void txtnomb_comp_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtapelli_comp_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        

        private void txtnumtelefono_comp_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtciud_comp_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }
    }
}
