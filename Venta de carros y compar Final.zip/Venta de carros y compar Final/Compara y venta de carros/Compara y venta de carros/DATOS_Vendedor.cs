﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Compara_y_venta_de_carros
{
    public partial class Datos_Vendedor : Form
    {
        public Datos_Vendedor()
        {
            InitializeComponent();
        }
        int i=1;
        int pos = 0;
        string nombre, apellido, telef, direc, razonvent, email, nacion, codpos, prov, marca, mod, matric, combus, fech1matri, fechaultmatri, estavehi, kilom, bast;
        private void limpiar()
        {
            txtnomb_vend.Text="";
           txtapelli_vend.Text="";
           txttelf_vend.Text = "";
           txtdirec_vend.Text = "";
           txtrazon__vend.Text = "";
           txtemail_vend.Text = "";
           txtnacionalidad_vend.Text = "";
           txtcodpos_vend.Text = "";
           txtprov_vend.Text = "";
           txtmarcavehi_vend.Text = "";
           txtmodvehi_vend.Text = "";
           txtmatricvehi_vend.Text = "";
           txtcombvehi_vend.Text = "";
           txtfech_prim_matri_vend.Text = "";
           txtfec_ult_matri_vend.Text = "";
           txtesta_vehi_vend.Text = "";
           txtkilomcont_vend.Text = "";
           txtnumbast_vend.Text = "";
            
        }
        private void btnguar_vend_Click(object sender, EventArgs e)
        {
            nombre = txtnomb_vend.Text;
            apellido = txtapelli_vend.Text;
            telef = txttelf_vend.Text;
            direc = txtdirec_vend.Text;
            razonvent = txtrazon__vend.Text;
            email = txtemail_vend.Text;
            nacion = txtnacionalidad_vend.Text;
            codpos = txtcodpos_vend.Text;
            prov = txtprov_vend.Text;
            marca = txtmarcavehi_vend.Text;
            mod = txtmodvehi_vend.Text;
            matric = txtmatricvehi_vend.Text;
            combus = txtcombvehi_vend.Text;
            fech1matri = txtfech_prim_matri_vend.Text;
            fechaultmatri = txtfec_ult_matri_vend.Text;
            estavehi = txtesta_vehi_vend.Text;
            kilom = txtkilomcont_vend.Text;
            bast = txtnumbast_vend.Text;
            dgvVendedor.Rows.Add(i, nombre, apellido, telef, direc, razonvent, email, nacion, codpos, prov, marca, mod, matric, combus, fech1matri, fechaultmatri, estavehi, kilom, bast);
            i++;
            
        }

        private void btnCnce_vend_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ESTA SEGURO ");
            if (DialogResult.Yes == DialogResult.Yes)
            {
                this.Close();
                limpiar();
                dgvVendedor.Rows.Clear();
            }
        }

        private void dgvVendedor_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            pos = dgvVendedor.CurrentRow.Index;
           
            txtnomb_vend.Text = dgvVendedor[1, pos].Value.ToString();
            txtapelli_vend.Text = dgvVendedor[2, pos].Value.ToString();
            txttelf_vend.Text = dgvVendedor[3, pos].Value.ToString();
            txtdirec_vend.Text = dgvVendedor[4, pos].Value.ToString();
            txtrazon__vend.Text = dgvVendedor[5, pos].Value.ToString();
            txtemail_vend.Text = dgvVendedor[6, pos].Value.ToString();
            txtnacionalidad_vend.Text = dgvVendedor[7, pos].Value.ToString();
            txtcodpos_vend.Text = dgvVendedor[8, pos].Value.ToString();
            txtprov_vend.Text = dgvVendedor[9, pos].Value.ToString();
            txtmarcavehi_vend.Text = dgvVendedor[10, pos].Value.ToString();
            txtmodvehi_vend.Text = dgvVendedor[11, pos].Value.ToString();
            txtmatricvehi_vend.Text = dgvVendedor[12, pos].Value.ToString();
            txtcombvehi_vend.Text = dgvVendedor[13, pos].Value.ToString();
            txtfech_prim_matri_vend.Text = dgvVendedor[14, pos].Value.ToString();
            txtfec_ult_matri_vend.Text = dgvVendedor[15, pos].Value.ToString();
            txtesta_vehi_vend.Text = dgvVendedor[16, pos].Value.ToString();
            txtkilomcont_vend.Text = dgvVendedor[17, pos].Value.ToString();
            txtnumbast_vend.Text = dgvVendedor[18, pos].Value.ToString();
            
        }

        private void txtnomb_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtapelli_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txttelf_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtprov_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtrazon__vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtnacionalidad_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtcodpos_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtcombvehi_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtkilomcont_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtnumbast_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtfech_prim_matri_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtfec_ult_matri_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

        private void txtesta_vehi_vend_KeyPress(object sender, KeyPressEventArgs e)
        {
            char letra = e.KeyChar;
            if (!char.IsLetter(letra) && letra != 13 && letra != 8 && letra != 32)
            {

                e.Handled = true;
            }
        }

    }
}
