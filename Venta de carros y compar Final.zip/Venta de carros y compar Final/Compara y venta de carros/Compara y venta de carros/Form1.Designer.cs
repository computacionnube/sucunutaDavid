﻿namespace Compara_y_venta_de_carros
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabCcArros1 = new System.Windows.Forms.TabControl();
            this.Inicio = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnVender = new System.Windows.Forms.Button();
            this.butModelos = new System.Windows.Forms.Button();
            this.tabcarro1 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lblPresio_Mits = new System.Windows.Forms.Label();
            this.btnsalir1 = new System.Windows.Forms.Button();
            this.btnsig1 = new System.Windows.Forms.Button();
            this.cmbSuc_Mits = new System.Windows.Forms.ComboBox();
            this.cmbVer_Mits = new System.Windows.Forms.ComboBox();
            this.cmbModel_Mits = new System.Windows.Forms.ComboBox();
            this.butCompMitsubishi = new System.Windows.Forms.Button();
            this.Pantalla1 = new System.Windows.Forms.PictureBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabcarro2 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lblprecio_acura = new System.Windows.Forms.Label();
            this.btnsalir2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnsig2 = new System.Windows.Forms.Button();
            this.btncomprAcura = new System.Windows.Forms.Button();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.cboversionacura = new System.Windows.Forms.ComboBox();
            this.cobmodeloacura = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.Pantalla2 = new System.Windows.Forms.PictureBox();
            this.tabcarro3 = new System.Windows.Forms.TabPage();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lblprecio_toyota = new System.Windows.Forms.Label();
            this.btnsalir3 = new System.Windows.Forms.Button();
            this.btnanterior3 = new System.Windows.Forms.Button();
            this.btncomprToyota = new System.Windows.Forms.Button();
            this.cmbsucur_Toyota = new System.Windows.Forms.ComboBox();
            this.cmbVer_Toyota = new System.Windows.Forms.ComboBox();
            this.cmbMod_Toyota = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Pantalla3 = new System.Windows.Forms.PictureBox();
            this.listimagen = new System.Windows.Forms.ImageList(this.components);
            this.RelogMIts = new System.Windows.Forms.Timer(this.components);
            this.lstAcura = new System.Windows.Forms.ImageList(this.components);
            this.lstTOYOTA = new System.Windows.Forms.ImageList(this.components);
            this.RelojAcura = new System.Windows.Forms.Timer(this.components);
            this.RelojToyota = new System.Windows.Forms.Timer(this.components);
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.tabCcArros1.SuspendLayout();
            this.Inicio.SuspendLayout();
            this.panel1.SuspendLayout();
            this.tabcarro1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pantalla1)).BeginInit();
            this.tabcarro2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pantalla2)).BeginInit();
            this.tabcarro3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pantalla3)).BeginInit();
            this.SuspendLayout();
            // 
            // tabCcArros1
            // 
            this.tabCcArros1.Controls.Add(this.Inicio);
            this.tabCcArros1.Controls.Add(this.tabcarro1);
            this.tabCcArros1.Controls.Add(this.tabcarro2);
            this.tabCcArros1.Controls.Add(this.tabcarro3);
            this.tabCcArros1.Location = new System.Drawing.Point(12, 21);
            this.tabCcArros1.Name = "tabCcArros1";
            this.tabCcArros1.SelectedIndex = 0;
            this.tabCcArros1.Size = new System.Drawing.Size(845, 323);
            this.tabCcArros1.TabIndex = 1;
            this.toolTip1.SetToolTip(this.tabCcArros1, "Sucursal");
            this.tabCcArros1.SelectedIndexChanged += new System.EventHandler(this.tabCcArros_SelectedIndexChanged);
            // 
            // Inicio
            // 
            this.Inicio.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Inicio.BackgroundImage")));
            this.Inicio.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Inicio.Controls.Add(this.panel1);
            this.Inicio.Location = new System.Drawing.Point(4, 22);
            this.Inicio.Name = "Inicio";
            this.Inicio.Padding = new System.Windows.Forms.Padding(3);
            this.Inicio.Size = new System.Drawing.Size(837, 297);
            this.Inicio.TabIndex = 0;
            this.Inicio.Text = "Registro";
            this.Inicio.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.btnVender);
            this.panel1.Controls.Add(this.butModelos);
            this.panel1.Location = new System.Drawing.Point(6, 20);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(780, 255);
            this.panel1.TabIndex = 0;
            // 
            // btnVender
            // 
            this.btnVender.Location = new System.Drawing.Point(571, 91);
            this.btnVender.Name = "btnVender";
            this.btnVender.Size = new System.Drawing.Size(75, 36);
            this.btnVender.TabIndex = 1;
            this.btnVender.Text = "VENDER";
            this.btnVender.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btnVender, "Vender");
            this.btnVender.UseVisualStyleBackColor = true;
            this.btnVender.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // butModelos
            // 
            this.butModelos.Location = new System.Drawing.Point(571, 33);
            this.butModelos.Name = "butModelos";
            this.butModelos.Size = new System.Drawing.Size(75, 30);
            this.butModelos.TabIndex = 0;
            this.butModelos.Text = "COMPRAR";
            this.butModelos.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.butModelos, "Comprar");
            this.butModelos.UseVisualStyleBackColor = true;
            this.butModelos.Click += new System.EventHandler(this.butModelos_Click);
            // 
            // tabcarro1
            // 
            this.tabcarro1.BackColor = System.Drawing.Color.Transparent;
            this.tabcarro1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("tabcarro1.BackgroundImage")));
            this.tabcarro1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabcarro1.Controls.Add(this.panel2);
            this.tabcarro1.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabcarro1.ImageKey = "(ninguno)";
            this.tabcarro1.Location = new System.Drawing.Point(4, 22);
            this.tabcarro1.Name = "tabcarro1";
            this.tabcarro1.Padding = new System.Windows.Forms.Padding(3);
            this.tabcarro1.Size = new System.Drawing.Size(837, 297);
            this.tabcarro1.TabIndex = 1;
            this.tabcarro1.Text = "Mitsubishi ";
            this.tabcarro1.ToolTipText = "Mitsubishi";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lblPresio_Mits);
            this.panel2.Controls.Add(this.btnsalir1);
            this.panel2.Controls.Add(this.btnsig1);
            this.panel2.Controls.Add(this.cmbSuc_Mits);
            this.panel2.Controls.Add(this.cmbVer_Mits);
            this.panel2.Controls.Add(this.cmbModel_Mits);
            this.panel2.Controls.Add(this.butCompMitsubishi);
            this.panel2.Controls.Add(this.Pantalla1);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(79, 25);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(656, 266);
            this.panel2.TabIndex = 0;
            // 
            // lblPresio_Mits
            // 
            this.lblPresio_Mits.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblPresio_Mits.Location = new System.Drawing.Point(106, 216);
            this.lblPresio_Mits.Name = "lblPresio_Mits";
            this.lblPresio_Mits.Size = new System.Drawing.Size(100, 23);
            this.lblPresio_Mits.TabIndex = 22;
            this.lblPresio_Mits.Text = "$ 00.00";
            this.toolTip1.SetToolTip(this.lblPresio_Mits, "Precio");
            // 
            // btnsalir1
            // 
            this.btnsalir1.Location = new System.Drawing.Point(540, 131);
            this.btnsalir1.Name = "btnsalir1";
            this.btnsalir1.Size = new System.Drawing.Size(75, 23);
            this.btnsalir1.TabIndex = 21;
            this.btnsalir1.Text = "CANCELAR";
            this.btnsalir1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btnsalir1, "Cancelar");
            this.btnsalir1.UseVisualStyleBackColor = true;
            this.btnsalir1.Click += new System.EventHandler(this.btnsalir1_Click);
            // 
            // btnsig1
            // 
            this.btnsig1.Location = new System.Drawing.Point(540, 216);
            this.btnsig1.Name = "btnsig1";
            this.btnsig1.Size = new System.Drawing.Size(75, 23);
            this.btnsig1.TabIndex = 11;
            this.btnsig1.Text = "SIGUIENTE";
            this.btnsig1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btnsig1, "Siguiente");
            this.btnsig1.UseVisualStyleBackColor = true;
            this.btnsig1.Click += new System.EventHandler(this.btnsig1_Click);
            // 
            // cmbSuc_Mits
            // 
            this.cmbSuc_Mits.FormattingEnabled = true;
            this.cmbSuc_Mits.Items.AddRange(new object[] {
            "Loja-Mosumi",
            "Oro-Mosumi",
            "Guayaquil-AutoWagen"});
            this.cmbSuc_Mits.Location = new System.Drawing.Point(103, 167);
            this.cmbSuc_Mits.Name = "cmbSuc_Mits";
            this.cmbSuc_Mits.Size = new System.Drawing.Size(121, 23);
            this.cmbSuc_Mits.TabIndex = 10;
            // 
            // cmbVer_Mits
            // 
            this.cmbVer_Mits.FormattingEnabled = true;
            this.cmbVer_Mits.Items.AddRange(new object[] {
            "4X2 HI RIDER",
            "4X4GLX",
            "4X4GLS TM",
            "4X4GLS TA",
            ""});
            this.cmbVer_Mits.Location = new System.Drawing.Point(103, 95);
            this.cmbVer_Mits.Name = "cmbVer_Mits";
            this.cmbVer_Mits.Size = new System.Drawing.Size(121, 23);
            this.cmbVer_Mits.TabIndex = 9;
            this.toolTip1.SetToolTip(this.cmbVer_Mits, "Vercion");
            this.cmbVer_Mits.SelectedIndexChanged += new System.EventHandler(this.cmbVer_Mits_SelectedIndexChanged);
            // 
            // cmbModel_Mits
            // 
            this.cmbModel_Mits.FormattingEnabled = true;
            this.cmbModel_Mits.Items.AddRange(new object[] {
            "SporteroL200",
            "Montero Sport",
            "Eclipse Cross"});
            this.cmbModel_Mits.Location = new System.Drawing.Point(103, 39);
            this.cmbModel_Mits.Name = "cmbModel_Mits";
            this.cmbModel_Mits.Size = new System.Drawing.Size(121, 23);
            this.cmbModel_Mits.TabIndex = 8;
            this.toolTip1.SetToolTip(this.cmbModel_Mits, "Modelo");
            this.cmbModel_Mits.SelectedIndexChanged += new System.EventHandler(this.cmbModel_Mits_SelectedIndexChanged);
            // 
            // butCompMitsubishi
            // 
            this.butCompMitsubishi.Location = new System.Drawing.Point(540, 170);
            this.butCompMitsubishi.Name = "butCompMitsubishi";
            this.butCompMitsubishi.Size = new System.Drawing.Size(75, 23);
            this.butCompMitsubishi.TabIndex = 7;
            this.butCompMitsubishi.Text = "COMPRAR";
            this.butCompMitsubishi.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.butCompMitsubishi, "Compar");
            this.butCompMitsubishi.UseVisualStyleBackColor = true;
            this.butCompMitsubishi.Click += new System.EventHandler(this.butComp_Click);
            // 
            // Pantalla1
            // 
            this.Pantalla1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Pantalla1.Location = new System.Drawing.Point(515, 19);
            this.Pantalla1.Name = "Pantalla1";
            this.Pantalla1.Size = new System.Drawing.Size(120, 97);
            this.Pantalla1.TabIndex = 6;
            this.Pantalla1.TabStop = false;
            this.toolTip1.SetToolTip(this.Pantalla1, "Modelos de los carros");
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(38, 170);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(49, 15);
            this.label4.TabIndex = 4;
            this.label4.Text = "Sucrsal";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(38, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(50, 15);
            this.label3.TabIndex = 3;
            this.label3.Text = "Version";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(38, 216);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(42, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "Precio";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(38, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Modelo";
            // 
            // tabcarro2
            // 
            this.tabcarro2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabcarro2.Controls.Add(this.panel3);
            this.tabcarro2.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabcarro2.Location = new System.Drawing.Point(4, 22);
            this.tabcarro2.Name = "tabcarro2";
            this.tabcarro2.Padding = new System.Windows.Forms.Padding(3);
            this.tabcarro2.Size = new System.Drawing.Size(837, 297);
            this.tabcarro2.TabIndex = 2;
            this.tabcarro2.Text = "Acura";
            this.tabcarro2.ToolTipText = "Acura";
            this.tabcarro2.UseVisualStyleBackColor = true;
            // 
            // panel3
            // 
            this.panel3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel3.BackgroundImage")));
            this.panel3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel3.Controls.Add(this.lblprecio_acura);
            this.panel3.Controls.Add(this.btnsalir2);
            this.panel3.Controls.Add(this.button3);
            this.panel3.Controls.Add(this.btnsig2);
            this.panel3.Controls.Add(this.btncomprAcura);
            this.panel3.Controls.Add(this.comboBox4);
            this.panel3.Controls.Add(this.cboversionacura);
            this.panel3.Controls.Add(this.cobmodeloacura);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.Pantalla2);
            this.panel3.Location = new System.Drawing.Point(54, 19);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(618, 272);
            this.panel3.TabIndex = 1;
            // 
            // lblprecio_acura
            // 
            this.lblprecio_acura.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblprecio_acura.Location = new System.Drawing.Point(87, 201);
            this.lblprecio_acura.Name = "lblprecio_acura";
            this.lblprecio_acura.Size = new System.Drawing.Size(100, 23);
            this.lblprecio_acura.TabIndex = 24;
            this.lblprecio_acura.Text = "$ 00.00";
            this.toolTip1.SetToolTip(this.lblprecio_acura, "Precio");
            // 
            // btnsalir2
            // 
            this.btnsalir2.Location = new System.Drawing.Point(390, 163);
            this.btnsalir2.Name = "btnsalir2";
            this.btnsalir2.Size = new System.Drawing.Size(75, 23);
            this.btnsalir2.TabIndex = 23;
            this.btnsalir2.Text = "CANCELAR";
            this.btnsalir2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btnsalir2, "Cancelar");
            this.btnsalir2.UseVisualStyleBackColor = true;
            this.btnsalir2.Click += new System.EventHandler(this.btnsalir2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(390, 209);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 22;
            this.button3.Text = "ANTERIOR";
            this.button3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.button3, "Anterior ");
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnsig2
            // 
            this.btnsig2.Location = new System.Drawing.Point(485, 209);
            this.btnsig2.Name = "btnsig2";
            this.btnsig2.Size = new System.Drawing.Size(75, 23);
            this.btnsig2.TabIndex = 21;
            this.btnsig2.Text = "SIGUIENTE";
            this.btnsig2.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btnsig2, "Siguiente");
            this.btnsig2.UseVisualStyleBackColor = true;
            this.btnsig2.Click += new System.EventHandler(this.btnsig2_Click);
            // 
            // btncomprAcura
            // 
            this.btncomprAcura.Location = new System.Drawing.Point(485, 163);
            this.btncomprAcura.Name = "btncomprAcura";
            this.btncomprAcura.Size = new System.Drawing.Size(75, 23);
            this.btncomprAcura.TabIndex = 19;
            this.btncomprAcura.Text = "COMPRAR";
            this.btncomprAcura.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btncomprAcura, "Compar");
            this.btncomprAcura.UseVisualStyleBackColor = true;
            this.btncomprAcura.Click += new System.EventHandler(this.btncomprAcura_Click);
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "GUAYAQUIL-Acura",
            "Oro-Acura",
            "Peru-AutoSer"});
            this.comboBox4.Location = new System.Drawing.Point(90, 160);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(121, 23);
            this.comboBox4.TabIndex = 17;
            // 
            // cboversionacura
            // 
            this.cboversionacura.FormattingEnabled = true;
            this.cboversionacura.Items.AddRange(new object[] {
            "SIMPLE",
            "COMPACTO",
            "CLASICO",
            ""});
            this.cboversionacura.Location = new System.Drawing.Point(90, 88);
            this.cboversionacura.Name = "cboversionacura";
            this.cboversionacura.Size = new System.Drawing.Size(121, 23);
            this.cboversionacura.TabIndex = 16;
            this.toolTip1.SetToolTip(this.cboversionacura, "Vercion");
            this.cboversionacura.SelectedIndexChanged += new System.EventHandler(this.cboversionacura_SelectedIndexChanged);
            // 
            // cobmodeloacura
            // 
            this.cobmodeloacura.FormattingEnabled = true;
            this.cobmodeloacura.Items.AddRange(new object[] {
            "2020 TLX",
            "Premium Luxury Sedan",
            "NSX"});
            this.cobmodeloacura.Location = new System.Drawing.Point(90, 32);
            this.cobmodeloacura.Name = "cobmodeloacura";
            this.cobmodeloacura.Size = new System.Drawing.Size(121, 23);
            this.cobmodeloacura.TabIndex = 15;
            this.toolTip1.SetToolTip(this.cobmodeloacura, "Modelo");
            this.cobmodeloacura.SelectedIndexChanged += new System.EventHandler(this.cbomodeloacura_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 163);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "Sucrsal";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(25, 88);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(50, 15);
            this.label6.TabIndex = 13;
            this.label6.Text = "Version";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(25, 209);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(42, 15);
            this.label7.TabIndex = 12;
            this.label7.Text = "Precio";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(25, 32);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 15);
            this.label8.TabIndex = 11;
            this.label8.Text = "Modelo";
            // 
            // Pantalla2
            // 
            this.Pantalla2.Location = new System.Drawing.Point(456, 32);
            this.Pantalla2.Name = "Pantalla2";
            this.Pantalla2.Size = new System.Drawing.Size(120, 97);
            this.Pantalla2.TabIndex = 0;
            this.Pantalla2.TabStop = false;
            this.toolTip1.SetToolTip(this.Pantalla2, "Modelos de los carros");
            // 
            // tabcarro3
            // 
            this.tabcarro3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabcarro3.Controls.Add(this.panel4);
            this.tabcarro3.Font = new System.Drawing.Font("MS Reference Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabcarro3.ImageKey = "(ninguno)";
            this.tabcarro3.Location = new System.Drawing.Point(4, 22);
            this.tabcarro3.Name = "tabcarro3";
            this.tabcarro3.Padding = new System.Windows.Forms.Padding(3);
            this.tabcarro3.Size = new System.Drawing.Size(837, 297);
            this.tabcarro3.TabIndex = 3;
            this.tabcarro3.Text = "Toyota";
            this.tabcarro3.ToolTipText = "Toyota";
            this.tabcarro3.UseVisualStyleBackColor = true;
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel4.Controls.Add(this.lblprecio_toyota);
            this.panel4.Controls.Add(this.btnsalir3);
            this.panel4.Controls.Add(this.btnanterior3);
            this.panel4.Controls.Add(this.btncomprToyota);
            this.panel4.Controls.Add(this.cmbsucur_Toyota);
            this.panel4.Controls.Add(this.cmbVer_Toyota);
            this.panel4.Controls.Add(this.cmbMod_Toyota);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.Pantalla3);
            this.panel4.Location = new System.Drawing.Point(97, 22);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(545, 272);
            this.panel4.TabIndex = 2;
            // 
            // lblprecio_toyota
            // 
            this.lblprecio_toyota.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblprecio_toyota.Location = new System.Drawing.Point(87, 209);
            this.lblprecio_toyota.Name = "lblprecio_toyota";
            this.lblprecio_toyota.Size = new System.Drawing.Size(100, 23);
            this.lblprecio_toyota.TabIndex = 25;
            this.lblprecio_toyota.Text = "$ 00.00";
            this.toolTip1.SetToolTip(this.lblprecio_toyota, "Precio");
            // 
            // btnsalir3
            // 
            this.btnsalir3.Location = new System.Drawing.Point(427, 201);
            this.btnsalir3.Name = "btnsalir3";
            this.btnsalir3.Size = new System.Drawing.Size(75, 23);
            this.btnsalir3.TabIndex = 20;
            this.btnsalir3.Text = "CANCELAR";
            this.btnsalir3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btnsalir3, "Cancelar");
            this.btnsalir3.UseVisualStyleBackColor = true;
            this.btnsalir3.Click += new System.EventHandler(this.btnsalir3_Click);
            // 
            // btnanterior3
            // 
            this.btnanterior3.Location = new System.Drawing.Point(427, 160);
            this.btnanterior3.Name = "btnanterior3";
            this.btnanterior3.Size = new System.Drawing.Size(75, 23);
            this.btnanterior3.TabIndex = 19;
            this.btnanterior3.Text = "ANTERIOR";
            this.btnanterior3.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btnanterior3, "Anterior");
            this.btnanterior3.UseVisualStyleBackColor = true;
            this.btnanterior3.Click += new System.EventHandler(this.button1_Click);
            // 
            // btncomprToyota
            // 
            this.btncomprToyota.Location = new System.Drawing.Point(427, 235);
            this.btncomprToyota.Name = "btncomprToyota";
            this.btncomprToyota.Size = new System.Drawing.Size(75, 23);
            this.btncomprToyota.TabIndex = 18;
            this.btncomprToyota.Text = "COMPRAR";
            this.btncomprToyota.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btncomprToyota, "Compar");
            this.btncomprToyota.UseVisualStyleBackColor = true;
            this.btncomprToyota.Click += new System.EventHandler(this.btncomprToyota_Click);
            // 
            // cmbsucur_Toyota
            // 
            this.cmbsucur_Toyota.FormattingEnabled = true;
            this.cmbsucur_Toyota.Items.AddRange(new object[] {
            "QUITO",
            "GUAYAQUIL",
            "LOJA"});
            this.cmbsucur_Toyota.Location = new System.Drawing.Point(90, 160);
            this.cmbsucur_Toyota.Name = "cmbsucur_Toyota";
            this.cmbsucur_Toyota.Size = new System.Drawing.Size(121, 23);
            this.cmbsucur_Toyota.TabIndex = 17;
            this.toolTip1.SetToolTip(this.cmbsucur_Toyota, "Sucursal");
            // 
            // cmbVer_Toyota
            // 
            this.cmbVer_Toyota.FormattingEnabled = true;
            this.cmbVer_Toyota.Items.AddRange(new object[] {
            "SE4X4E",
            "COMPACTO 4X4",
            "CLASICO STANDEM",
            "MV4X4OCEAN"});
            this.cmbVer_Toyota.Location = new System.Drawing.Point(90, 88);
            this.cmbVer_Toyota.Name = "cmbVer_Toyota";
            this.cmbVer_Toyota.Size = new System.Drawing.Size(121, 23);
            this.cmbVer_Toyota.TabIndex = 16;
            this.toolTip1.SetToolTip(this.cmbVer_Toyota, "Vercion");
            this.cmbVer_Toyota.SelectedIndexChanged += new System.EventHandler(this.cmbVer_Toyota_SelectedIndexChanged);
            // 
            // cmbMod_Toyota
            // 
            this.cmbMod_Toyota.FormattingEnabled = true;
            this.cmbMod_Toyota.Items.AddRange(new object[] {
            "Prius C Sport",
            "Yaris Automático",
            "Prius 4G",
            "RAV4"});
            this.cmbMod_Toyota.Location = new System.Drawing.Point(90, 32);
            this.cmbMod_Toyota.Name = "cmbMod_Toyota";
            this.cmbMod_Toyota.Size = new System.Drawing.Size(121, 23);
            this.cmbMod_Toyota.TabIndex = 15;
            this.toolTip1.SetToolTip(this.cmbMod_Toyota, "Modelo");
            this.cmbMod_Toyota.SelectedIndexChanged += new System.EventHandler(this.cmbMod_Toyota_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(25, 163);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 15);
            this.label9.TabIndex = 14;
            this.label9.Text = "Sucrsal";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(25, 88);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(50, 15);
            this.label10.TabIndex = 13;
            this.label10.Text = "Version";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(25, 209);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 15);
            this.label11.TabIndex = 12;
            this.label11.Text = "Precio";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(25, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(47, 15);
            this.label12.TabIndex = 11;
            this.label12.Text = "Modelo";
            // 
            // Pantalla3
            // 
            this.Pantalla3.Location = new System.Drawing.Point(414, 34);
            this.Pantalla3.Name = "Pantalla3";
            this.Pantalla3.Size = new System.Drawing.Size(116, 77);
            this.Pantalla3.TabIndex = 0;
            this.Pantalla3.TabStop = false;
            this.toolTip1.SetToolTip(this.Pantalla3, "Modelos de los carros");
            // 
            // listimagen
            // 
            this.listimagen.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("listimagen.ImageStream")));
            this.listimagen.TransparentColor = System.Drawing.Color.Transparent;
            this.listimagen.Images.SetKeyName(0, "1864173_2_w.jpg");
            this.listimagen.Images.SetKeyName(1, "VA_19f6d1d1eb4341d689ee30a2ba5ddb6b (1).jpg");
            this.listimagen.Images.SetKeyName(2, "3-P1020930-8.jpg");
            this.listimagen.Images.SetKeyName(3, "home-mirage.jpg");
            // 
            // RelogMIts
            // 
            this.RelogMIts.Interval = 1000;
            this.RelogMIts.Tick += new System.EventHandler(this.RelogMIts_Tick);
            // 
            // lstAcura
            // 
            this.lstAcura.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("lstAcura.ImageStream")));
            this.lstAcura.TransparentColor = System.Drawing.Color.Transparent;
            this.lstAcura.Images.SetKeyName(0, "2019-Acura-NSX-gallery-slash-5-large.jpg");
            this.lstAcura.Images.SetKeyName(1, "tlx2020.jpg");
            this.lstAcura.Images.SetKeyName(2, "TLX20-093_SteelCAR_Seq_00036.jpg");
            // 
            // lstTOYOTA
            // 
            this.lstTOYOTA.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("lstTOYOTA.ImageStream")));
            this.lstTOYOTA.TransparentColor = System.Drawing.Color.Transparent;
            this.lstTOYOTA.Images.SetKeyName(0, "1GALERÍA.png");
            this.lstTOYOTA.Images.SetKeyName(1, "1170x400-frontal.jpg");
            this.lstTOYOTA.Images.SetKeyName(2, "Versiones_Prius_C_Sport.png");
            this.lstTOYOTA.Images.SetKeyName(3, "yaris-PORTADA.png");
            // 
            // RelojAcura
            // 
            this.RelojAcura.Interval = 1000;
            this.RelojAcura.Tick += new System.EventHandler(this.RelojAcura_Tick);
            // 
            // RelojToyota
            // 
            this.RelojToyota.Interval = 1000;
            this.RelojToyota.Tick += new System.EventHandler(this.RelojToyota_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 491);
            this.Controls.Add(this.tabCcArros1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabCcArros1.ResumeLayout(false);
            this.Inicio.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.tabcarro1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pantalla1)).EndInit();
            this.tabcarro2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pantalla2)).EndInit();
            this.tabcarro3.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Pantalla3)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabCcArros1;
        private System.Windows.Forms.TabPage Inicio;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tabcarro1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox Pantalla1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ImageList listimagen;
        private System.Windows.Forms.Timer RelogMIts;
        private System.Windows.Forms.Button butModelos;
        private System.Windows.Forms.Button butCompMitsubishi;
        private System.Windows.Forms.ComboBox cmbSuc_Mits;
        private System.Windows.Forms.ComboBox cmbVer_Mits;
        private System.Windows.Forms.ComboBox cmbModel_Mits;
        private System.Windows.Forms.TabPage tabcarro2;
        private System.Windows.Forms.PictureBox Pantalla2;
        private System.Windows.Forms.TabPage tabcarro3;
        private System.Windows.Forms.ImageList lstAcura;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox cboversionacura;
        private System.Windows.Forms.ComboBox cobmodeloacura;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.ComboBox cmbsucur_Toyota;
        private System.Windows.Forms.ComboBox cmbVer_Toyota;
        private System.Windows.Forms.ComboBox cmbMod_Toyota;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.PictureBox Pantalla3;
        private System.Windows.Forms.Button btncomprAcura;
        private System.Windows.Forms.Button btncomprToyota;
        private System.Windows.Forms.ImageList lstTOYOTA;
        private System.Windows.Forms.Button btnsig1;
        private System.Windows.Forms.Timer RelojAcura;
        private System.Windows.Forms.Timer RelojToyota;
        private System.Windows.Forms.Button btnsig2;
        private System.Windows.Forms.Button btnsalir3;
        private System.Windows.Forms.Button btnanterior3;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnsalir1;
        private System.Windows.Forms.Button btnsalir2;
        private System.Windows.Forms.Button btnVender;
        private System.Windows.Forms.Label lblPresio_Mits;
        private System.Windows.Forms.Label lblprecio_acura;
        private System.Windows.Forms.Label lblprecio_toyota;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}

