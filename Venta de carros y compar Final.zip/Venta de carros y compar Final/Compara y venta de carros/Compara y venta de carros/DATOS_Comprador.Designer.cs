﻿namespace Compara_y_venta_de_carros
{
    partial class DATOS_Comprador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtnomb_comp = new System.Windows.Forms.TextBox();
            this.txtapelli_comp = new System.Windows.Forms.TextBox();
            this.txtemail_comp = new System.Windows.Forms.TextBox();
            this.txtnumtelefono_comp = new System.Windows.Forms.TextBox();
            this.txtdirec_comp = new System.Windows.Forms.TextBox();
            this.txtciud_comp = new System.Windows.Forms.TextBox();
            this.btnSAlircom = new System.Windows.Forms.Button();
            this.btnGuardarCompr = new System.Windows.Forms.Button();
            this.dgvDATOS_comprador = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nombre_comp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.apellido_comp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email_comp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Direccion_comp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.numtelf_comp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ciudad_comp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnedit_comp = new System.Windows.Forms.Button();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dgvDATOS_comprador)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(31, 31);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "NOMBRES";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(365, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "APELLIDOS";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(31, 110);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Email";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(365, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Numero Telefono";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(31, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Direccion";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(365, 162);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(40, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Ciudad";
            // 
            // txtnomb_comp
            // 
            this.txtnomb_comp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtnomb_comp.Location = new System.Drawing.Point(126, 31);
            this.txtnomb_comp.Name = "txtnomb_comp";
            this.txtnomb_comp.Size = new System.Drawing.Size(212, 20);
            this.txtnomb_comp.TabIndex = 6;
            this.txtnomb_comp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnomb_comp_KeyPress);
            // 
            // txtapelli_comp
            // 
            this.txtapelli_comp.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtapelli_comp.Location = new System.Drawing.Point(464, 31);
            this.txtapelli_comp.Name = "txtapelli_comp";
            this.txtapelli_comp.Size = new System.Drawing.Size(212, 20);
            this.txtapelli_comp.TabIndex = 7;
            this.txtapelli_comp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtapelli_comp_KeyPress);
            // 
            // txtemail_comp
            // 
            this.txtemail_comp.Location = new System.Drawing.Point(126, 103);
            this.txtemail_comp.Name = "txtemail_comp";
            this.txtemail_comp.Size = new System.Drawing.Size(212, 20);
            this.txtemail_comp.TabIndex = 8;
            // 
            // txtnumtelefono_comp
            // 
            this.txtnumtelefono_comp.Location = new System.Drawing.Point(464, 76);
            this.txtnumtelefono_comp.Name = "txtnumtelefono_comp";
            this.txtnumtelefono_comp.Size = new System.Drawing.Size(212, 20);
            this.txtnumtelefono_comp.TabIndex = 9;
            this.txtnumtelefono_comp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnumtelefono_comp_KeyPress);
            // 
            // txtdirec_comp
            // 
            this.txtdirec_comp.Location = new System.Drawing.Point(126, 159);
            this.txtdirec_comp.Name = "txtdirec_comp";
            this.txtdirec_comp.Size = new System.Drawing.Size(212, 20);
            this.txtdirec_comp.TabIndex = 10;
            // 
            // txtciud_comp
            // 
            this.txtciud_comp.Location = new System.Drawing.Point(464, 166);
            this.txtciud_comp.Name = "txtciud_comp";
            this.txtciud_comp.Size = new System.Drawing.Size(143, 20);
            this.txtciud_comp.TabIndex = 11;
            this.txtciud_comp.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtciud_comp_KeyPress);
            // 
            // btnSAlircom
            // 
            this.btnSAlircom.Location = new System.Drawing.Point(762, 226);
            this.btnSAlircom.Name = "btnSAlircom";
            this.btnSAlircom.Size = new System.Drawing.Size(91, 23);
            this.btnSAlircom.TabIndex = 12;
            this.btnSAlircom.Text = "CANCELAR";
            this.btnSAlircom.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btnSAlircom, "Cancelar");
            this.btnSAlircom.UseVisualStyleBackColor = true;
            this.btnSAlircom.Click += new System.EventHandler(this.btnSAlircom_Click);
            // 
            // btnGuardarCompr
            // 
            this.btnGuardarCompr.Location = new System.Drawing.Point(762, 271);
            this.btnGuardarCompr.Name = "btnGuardarCompr";
            this.btnGuardarCompr.Size = new System.Drawing.Size(91, 23);
            this.btnGuardarCompr.TabIndex = 13;
            this.btnGuardarCompr.Text = "GUARDAR";
            this.btnGuardarCompr.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btnGuardarCompr, "Guardar");
            this.btnGuardarCompr.UseVisualStyleBackColor = true;
            this.btnGuardarCompr.Click += new System.EventHandler(this.btnGuardarCompr_Click);
            // 
            // dgvDATOS_comprador
            // 
            this.dgvDATOS_comprador.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvDATOS_comprador.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.nombre_comp,
            this.apellido_comp,
            this.email_comp,
            this.Direccion_comp,
            this.numtelf_comp,
            this.ciudad_comp});
            this.dgvDATOS_comprador.Location = new System.Drawing.Point(12, 226);
            this.dgvDATOS_comprador.Name = "dgvDATOS_comprador";
            this.dgvDATOS_comprador.Size = new System.Drawing.Size(744, 130);
            this.dgvDATOS_comprador.TabIndex = 14;
            this.dgvDATOS_comprador.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvDATOS_comprador_CellClick);
            // 
            // Column1
            // 
            this.Column1.HeaderText = "#";
            this.Column1.Name = "Column1";
            // 
            // nombre_comp
            // 
            this.nombre_comp.HeaderText = "NOMBRES";
            this.nombre_comp.Name = "nombre_comp";
            // 
            // apellido_comp
            // 
            this.apellido_comp.HeaderText = "APELLIDOS";
            this.apellido_comp.Name = "apellido_comp";
            // 
            // email_comp
            // 
            this.email_comp.HeaderText = "Email";
            this.email_comp.Name = "email_comp";
            // 
            // Direccion_comp
            // 
            this.Direccion_comp.HeaderText = "DIRECCION";
            this.Direccion_comp.Name = "Direccion_comp";
            // 
            // numtelf_comp
            // 
            this.numtelf_comp.HeaderText = "TELEFONO";
            this.numtelf_comp.Name = "numtelf_comp";
            // 
            // ciudad_comp
            // 
            this.ciudad_comp.HeaderText = "CIUDAD";
            this.ciudad_comp.Name = "ciudad_comp";
            // 
            // btnedit_comp
            // 
            this.btnedit_comp.Location = new System.Drawing.Point(762, 327);
            this.btnedit_comp.Name = "btnedit_comp";
            this.btnedit_comp.Size = new System.Drawing.Size(91, 23);
            this.btnedit_comp.TabIndex = 15;
            this.btnedit_comp.Text = "EDITAR";
            this.btnedit_comp.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage;
            this.toolTip1.SetToolTip(this.btnedit_comp, "Editar");
            this.btnedit_comp.UseVisualStyleBackColor = true;
            this.btnedit_comp.Click += new System.EventHandler(this.btnedit_comp_Click);
            // 
            // DATOS_Comprador
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(860, 362);
            this.Controls.Add(this.btnedit_comp);
            this.Controls.Add(this.dgvDATOS_comprador);
            this.Controls.Add(this.btnGuardarCompr);
            this.Controls.Add(this.btnSAlircom);
            this.Controls.Add(this.txtciud_comp);
            this.Controls.Add(this.txtdirec_comp);
            this.Controls.Add(this.txtnumtelefono_comp);
            this.Controls.Add(this.txtemail_comp);
            this.Controls.Add(this.txtapelli_comp);
            this.Controls.Add(this.txtnomb_comp);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "DATOS_Comprador";
            this.Text = "DATOS_Comprador";
            ((System.ComponentModel.ISupportInitialize)(this.dgvDATOS_comprador)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtnomb_comp;
        private System.Windows.Forms.TextBox txtapelli_comp;
        private System.Windows.Forms.TextBox txtemail_comp;
        private System.Windows.Forms.TextBox txtnumtelefono_comp;
        private System.Windows.Forms.TextBox txtdirec_comp;
        private System.Windows.Forms.TextBox txtciud_comp;
        private System.Windows.Forms.Button btnSAlircom;
        private System.Windows.Forms.Button btnGuardarCompr;
        private System.Windows.Forms.DataGridView dgvDATOS_comprador;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nombre_comp;
        private System.Windows.Forms.DataGridViewTextBoxColumn apellido_comp;
        private System.Windows.Forms.DataGridViewTextBoxColumn email_comp;
        private System.Windows.Forms.DataGridViewTextBoxColumn Direccion_comp;
        private System.Windows.Forms.DataGridViewTextBoxColumn numtelf_comp;
        private System.Windows.Forms.DataGridViewTextBoxColumn ciudad_comp;
        private System.Windows.Forms.Button btnedit_comp;
        private System.Windows.Forms.ToolTip toolTip1;
    }
}